package studi_kasus;

public class Vertex {
    String idVertex;
    Edge edge;
    Vertex next;
}