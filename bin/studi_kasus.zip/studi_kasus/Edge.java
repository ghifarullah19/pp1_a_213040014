package studi_kasus;

public class Edge {
	int cost;
	Edge next;
	Vertex tujuan;
}
