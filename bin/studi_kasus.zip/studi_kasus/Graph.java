package studi_kasus;

public class Graph {
    Graph G;
    Vertex first;
}
